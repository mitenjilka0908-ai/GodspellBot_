import discord 
from discord .ext import commands 


class __boost(commands .Cog ):
    def __init__ (self ,bot ):
        self .bot =bot 

    """Boost commands"""

    def help_custom (self ):
              emoji ='<:boost:1448966463586041906>'
              label ="Boost Commands"
              description ="Show you the commands of boost"
              return emoji ,label ,description 

    @commands .group ()
    async def __Boost__ (self ,ctx :commands .Context ):
        """`boost setup` , `boost message` , `boost channel` , `boostrole` , `boost config`"""
        pass
